<?php
$host = 'localhost';
$user = 'uxx';
$pass = 'your password';
$dbname = 'uxx';

$suppliers = json_decode(file_get_contents('suppliers_100.json'), true);

$sqlFile = fopen('suppliers_orders_inserts.sql', 'w');

// Generate SQL inserts for suppliers and supplier phones
foreach ($suppliers as $supplier) {
    if (!isset($supplier['_id']) || !isset($supplier['name']) || !isset($supplier['email'])) continue;

    $supplier_id = $supplier['_id'];
    $name = addslashes($supplier['name']);
    $email = addslashes($supplier['email']);

    fwrite($sqlFile, "INSERT INTO suppliers (supplier_id, name, email) VALUES ($supplier_id, '$name', '$email') ON DUPLICATE KEY UPDATE name='$name', email='$email';\n");

    if (isset($supplier['tel']) && is_array($supplier['tel'])) {
        foreach ($supplier['tel'] as $phone_entry) {
            if (isset($phone_entry['number']) && is_string($phone_entry['number'])) {
                $phone = addslashes($phone_entry['number']);
                fwrite($sqlFile, "INSERT INTO supplier_phones (supplier_id, phone_number) VALUES ($supplier_id, '$phone');\n");
            }
        }
    }
}

// Now handle orders line-by-line, combining duplicate part_id quantities
$orderFile = fopen('orders_4000.json', 'r');
$order_id_counter = 1;

while (($line = fgets($orderFile)) !== false) {
    $order = json_decode($line, true);
    if (!isset($order['supp_id']) || !isset($order['when']) || !isset($order['items'])) continue;

    $supplier_id = $order['supp_id'];
    $order_date = $order['when'];

    fwrite($sqlFile, "INSERT INTO orders (order_id, supplier_id, order_date) VALUES ($order_id_counter, $supplier_id, '$order_date') ON DUPLICATE KEY UPDATE supplier_id=$supplier_id, order_date='$order_date';\n");

    // Combine part quantities if duplicates appear
    $parts_map = [];
    foreach ($order['items'] as $item) {
        if (isset($item['part_id']) && isset($item['qty'])) {
            $part_id = $item['part_id'];
            $quantity = $item['qty'];

            if (isset($parts_map[$part_id])) {
                $parts_map[$part_id] += $quantity;
            } else {
                $parts_map[$part_id] = $quantity;
            }
        }
    }

    // Write combined parts inserts
    foreach ($parts_map as $part_id => $quantity) {
        fwrite($sqlFile, "INSERT INTO order_parts (order_id, part_id, quantity) VALUES ($order_id_counter, $part_id, $quantity);\n");
    }

    $order_id_counter++;
}

fclose($orderFile);
fclose($sqlFile);
echo "SQL insert statements for suppliers, phones, orders, and combined order parts written to suppliers_orders_inserts.sql";
