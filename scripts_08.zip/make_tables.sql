-- make_tables.sql

-- Drop tables if they already exist (order matters because of FK constraints)
DROP TABLE IF EXISTS order_parts;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS supplier_phones;
DROP TABLE IF EXISTS suppliers;

-- Create suppliers table
CREATE TABLE suppliers (
    supplier_id INT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL
);

-- Create supplier_phones table
CREATE TABLE supplier_phones (
    phone_id INT AUTO_INCREMENT PRIMARY KEY,
    supplier_id INT,
    phone_number VARCHAR(50) NOT NULL,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id) ON DELETE CASCADE
);

-- Create orders table
CREATE TABLE orders (
    order_id INT PRIMARY KEY,
    supplier_id INT,
    order_date DATE NOT NULL,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id) ON DELETE CASCADE
);

-- Create order_parts table
CREATE TABLE order_parts (
    order_id INT,
    part_id INT,
    quantity INT NOT NULL,
    PRIMARY KEY (order_id, part_id),
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (part_id) REFERENCES parts(_id) ON DELETE CASCADE
);
