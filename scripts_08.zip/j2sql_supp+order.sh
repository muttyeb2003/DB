#!/bin/bash

# Replace with your credentials
user="uxx"
pass="your password"
db="uxx"

# Step 1: Run make_tables.sql to create the necessary tables
echo "Running make_tables.sql to create tables..."
mysql -u$user -p$pass $db < make_tables.sql

# Step 2: Generate SQL insert statements from JSON using PHP
echo "Generating SQL insert statements from suppliers_100.json and orders_4000.json..."
php generate_inserts.php

# Step 3: Load the generated SQL insert statements into MySQL
echo "Loading data into MySQL from suppliers_orders_inserts.sql..."
mysql -u$user -p$pass $db < suppliers_orders_inserts.sql

echo "All suppliers and orders loaded successfully."
